``cassandra.cqlengine.connection`` - Connection management for cqlengine
========================================================================

.. module:: cassandra.cqlengine.connection

.. autofunction:: default

.. autofunction:: set_session

.. autofunction:: setup

.. autofunction:: register_connection

.. autofunction:: unregister_connection

.. autofunction:: set_default_connection
