``cassandra.io.twistedreactor`` - Twisted Event Loop
====================================================

.. module:: cassandra.io.twistedreactor

.. class:: TwistedConnection

   An implementation of :class:`~cassandra.io.connection.Connection` that uses
   Twisted's reactor as its event loop.
