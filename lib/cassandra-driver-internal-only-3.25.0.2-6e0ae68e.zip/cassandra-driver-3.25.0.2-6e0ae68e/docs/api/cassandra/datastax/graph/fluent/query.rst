:mod:`cassandra.datastax.graph.fluent.query`
============================================

.. module:: cassandra.datastax.graph.fluent.query


.. autoclass:: TraversalBatch
   :members:
